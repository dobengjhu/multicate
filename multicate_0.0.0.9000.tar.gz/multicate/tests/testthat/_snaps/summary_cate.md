# summary.cate generates expected errors/warnings

    Code
      plot.cate("Not a cate object")
    Condition
      Error:
      ! use only with "cate" objects

